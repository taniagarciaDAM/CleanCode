/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.util.InputMismatchException;
import java.util.Scanner;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;



import cleancode.*;

/**
 *
 * @author Tania
 */
public class CleanCode2Test {  
    
    Verduras zanahorias;
    Verduras berenjenas;
    Verduras calabacines;
    Frutas naranjas;
    Frutas platanos;
    Frutas manzanas;

     @BeforeEach
    public void setUp() {
    Verduras berenjenas = new Verduras("berenjenas", 3, "10 días");
    Verduras zanahorias = new Verduras("zanahorias", 6, "10 días");
    Verduras calabacines = new Verduras("calabacines", 1, "12 días");
    Frutas naranjas = new Frutas("naranjas", 5, "7 días");
    Frutas platanos = new Frutas("platanos", 8, "12 días");
    Frutas manzanas = new Frutas("manzanas", 5, "20 días");   
    }

      @Test
    public void testContarVerduras() {
   
        int totalVerduras = zanahorias.getCantidad() + berenjenas.getCantidad() + calabacines.getCantidad();
        
        // Se verifica que el resultado sea el esperado
        assertEquals(10, totalVerduras);
    }

    @Test
    public void testContarFrutas() {
 
        int totalFrutas = platanos.getCantidad() + naranjas.getCantidad() + manzanas.getCantidad();
        
        assertEquals(18, totalFrutas); // Se espera 18 frutas en total
    }

    @Test
    public void testAgregarProducto() {
        // Prueba agregar un número válido de naranjas
        Scanner scanner1 = new Scanner("5");
        assertDoesNotThrow(() -> nevera.agregarProducto(scanner1, "naranjas"));
        assertEquals(10, nevera.naranjas.getCantidad()); // Se espera que la cantidad de naranjas sea 10

        // Prueba agregar un número inválido de plátanos
        Scanner scanner2 = new Scanner("cincuenta");
        assertThrows(InputMismatchException.class, () -> nevera.agregarProducto(scanner2, "platanos")); // Se espera una excepción InputMismatchException
        assertEquals(8, nevera.platanos.getCantidad()); // Se espera que la cantidad de plátanos siga siendo 8

        // Prueba agregar un número negativo de manzanas
        Scanner scanner3 = new Scanner("-3");
        assertThrows(IllegalArgumentException.class, () -> nevera.agregarProducto(scanner3, "manzanas")); // Se espera una excepción IllegalArgumentException
        assertEquals(5, nevera.manzanas.getCantidad()); // Se espera que la cantidad de manzanas siga siendo 5
    }
    
   
}
