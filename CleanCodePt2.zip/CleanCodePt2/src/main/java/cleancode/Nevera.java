/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cleancode;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Tania
 */
public class Nevera {
    
    
        Verduras berenjenas = new Verduras("berenjenas", 3, "10 días");
        Verduras zanahorias = new Verduras("zanahorias", 6, "10 días");
        Verduras calabacines = new Verduras("calabacines", 1, "12 días");
        Frutas naranjas = new Frutas("naranjas", 5, "7 días");
        Frutas platanos = new Frutas("platanos", 8, "12 días");
        Frutas manzanas = new Frutas("manzanas", 5, "20 días");
    
   

        
    public void ContarVerduras(){
    int totalVerduras = 0;
    totalVerduras = zanahorias.getCantidad() + berenjenas.getCantidad() + calabacines.getCantidad();
    }

  
    public void ContarFrutas(){
    int totalFrutas = 0;
    totalFrutas = platanos.getCantidad() + naranjas.getCantidad() + manzanas.getCantidad();
    }

public void agregarProducto(Scanner scanner, String producto) throws InputMismatchException {
    System.out.println("Ingrese la cantidad de " + producto + " que ha comprado:");
    try {
        int cantidadComprada = scanner.nextInt();
        switch (producto) {
            case "naranjas":
                naranjas.agregarCantidad(cantidadComprada);
                break;
            case "platanos":
                platanos.agregarCantidad(cantidadComprada);
                break;
            case "manzanas":
                manzanas.agregarCantidad(cantidadComprada);
                break;
            case "berenjenas":
                berenjenas.agregarCantidad(cantidadComprada);
                break;
            case "zanahorias":
                zanahorias.agregarCantidad(cantidadComprada);
                break;
            case "calabacines":
                calabacines.agregarCantidad(cantidadComprada);
                break;
            default:
                throw new InputMismatchException("Producto no válido");
        }
    } catch (InputMismatchException e) {
        System.out.println("Error: Se esperaba un número entero para la cantidad");
    } finally {
        scanner.nextLine(); // Limpiar el buffer del scanner
    }
}

    public void mostrarInventario() {
        System.out.println("Inventario en la nevera:");
        System.out.println("Naranjas: " + naranjas.getCantidad());
        System.out.println("Plátanos: " + platanos.getCantidad());
        System.out.println("Manzanas: " + manzanas.getCantidad());
        System.out.println("Berenjenas: " + berenjenas.getCantidad());
        System.out.println("Zanahorias: " + zanahorias.getCantidad());
        System.out.println("Calabacines: " + calabacines.getCantidad());
    }
}