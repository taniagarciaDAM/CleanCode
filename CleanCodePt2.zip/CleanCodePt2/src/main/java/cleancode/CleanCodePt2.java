/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package cleancode;

/**
 *
 * @author Tania
 */
public class CleanCodePt2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
