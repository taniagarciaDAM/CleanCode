/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cleancode;

/**
 *
 * @author Tania
 */
public class Verduras extends Producto {
    public Verduras(String nombre, int cantidad, final String CADUCIDAD) {
        super(nombre, cantidad, CADUCIDAD);
    }
    
}
